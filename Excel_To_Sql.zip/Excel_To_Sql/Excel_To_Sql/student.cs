﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Excel_To_Sql
{
    public class student
    {
        public int student_id { get; set; }
        public string student_name { get; set; }
        public int age { get; set; }
        public string phone { get; set; }
    }
}
