﻿using ExcelDataReader;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Z.Dapper.Plus;

namespace Excel_To_Sql
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
        DataTableCollection tableCollection;

        private void button1_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog openFileDialog = new OpenFileDialog() { Filter = "Excel 97-2083 Workbook|*.xls| Excel Workbooks|*.xlsx" })
            {
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    textBox1.Text = openFileDialog.FileName;
                    using (var stream = File.Open(openFileDialog.FileName, FileMode.Open, FileAccess.Read))
                    {
                        using (IExcelDataReader reader = ExcelReaderFactory.CreateReader(stream))
                        {
                            DataSet result = reader.AsDataSet(new ExcelDataSetConfiguration()
                            {

                                ConfigureDataTable = (_) => new ExcelDataTableConfiguration() { UseHeaderRow = true }
                            });

                            tableCollection = result.Tables; comboBox1.Items.Clear();
                            foreach (DataTable table in tableCollection)
                                comboBox1.Items.Add(table.TableName);//add
                        }
                    }
                }
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataTable dt = tableCollection[comboBox1.SelectedItem.ToString()];
            //dataGridView1.DataSource = dt;
            if(dt != null)
            {
                List<student> students = new List<student>();
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    student student = new student();
                    student.student_id = Int16.Parse(dt.Rows[i]["student_id"].ToString());
                    student.student_name=dt.Rows[i]["student_name"].ToString();
                    student.age=Int16.Parse(dt.Rows[i]["age"].ToString());
                    student.phone=dt.Rows[i]["phone"].ToString();
                    students.Add(student);

                }
                
                studentsBindingSource.DataSource = students;
            }
            

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'testDataSet.students' table. You can move, or remove it, as needed.
            this.studentsTableAdapter.Fill(this.testDataSet.students);

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source=IN-PPM107643\\SQLEXPRESS02;Initial Catalog=test;Integrated Security=True";
            DapperPlusManager.Entity<student>().Table("students");
            List<student> students = studentsBindingSource.DataSource as List<student>;
            if (students != null)
            {
                
                using (IDbConnection dbConnection = new SqlConnection(connectionString))
                {
                    dbConnection.BulkInsert(students);
                }
            }
            MessageBox.Show("completed buddy");
        }
    }
}
